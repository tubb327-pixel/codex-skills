Read `AGENTS.md` and activate the umbrella skill `solana-trading-system` plus any matching lower-level skills under `.agents/skills`.

Task:
Build a production-grade Solana trading system in Rust with two components.

1. An Anchor program that:
- stores strategy configuration and risk limits
- validates authorized executors
- controls vault PDAs/token authority where applicable
- enforces max position size, cooldowns, slippage ceiling, daily loss cap, and emergency stop
- records compact trade/risk state

2. An off-chain Rust executor that:
- connects to live Solana RPC and WebSocket endpoints
- ingests real market/pool/trade data
- computes trading signals
- integrates Jupiter through an adapter layer
- supports Pump.fun-style launch detection as a separate detection pipeline
- submits transactions invoking the Anchor program
- tracks confirmations and reconciliation

Non-negotiables:
- no mock, simulated, or placeholder data in implementation code
- if a required real source is missing, leave a clear `UNIMPLEMENTED_UNTIL_REAL_SOURCE_CONNECTED` marker
- do not invent schemas or program IDs; isolate unknowns behind interfaces
- prefer auditable modules and explicit error handling

Deliver in phases:
1. repo bootstrap and workspace layout
2. architecture and crate boundaries
3. Anchor accounts, instructions, state, and validations
4. executor modules, routing adapters, and detection pipeline
5. config/env surface and operational docs
6. compile/lint/test workflow
7. unresolved live dependency list
