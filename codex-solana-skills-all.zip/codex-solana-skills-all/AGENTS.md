# Codex instructions for this repository

## Mission
Build production-grade Solana trading infrastructure in Rust and Anchor.

## Hard rules
- Never use mock, fake, placeholder, or simulated market data in implementation code.
- If a required live source is unavailable, leave the module clearly marked `UNIMPLEMENTED_UNTIL_REAL_SOURCE_CONNECTED`.
- Prefer Rust for both on-chain and off-chain components unless a file explicitly requires another language.
- Keep risk controls enforced on-chain whenever practical.
- Do not weaken guardrails to make tests pass.
- Do not invent program IDs, account layouts, API responses, or instruction schemas. Mark unknowns and isolate them behind traits/interfaces.
- Before editing, inspect the nearest `AGENTS.md` and relevant skills under `.agents/skills`.

## Architecture defaults
- One Anchor program for config, executor authorization, vault control, and risk enforcement.
- One off-chain executor for data ingest, signal generation, transaction assembly, and submission.
- DEX/routing integrations should be adapter-driven.
- All external services must be wrapped in interfaces with explicit error handling and retries.

## Implementation expectations
- Favor small, auditable modules.
- Add structured logging.
- Add integration points for RPC, WebSocket, market data, and persistence.
- Use environment variables for secrets and endpoints.
- Keep comments precise and operational.

## Validation workflow
- Run formatting and compile checks for changed Rust crates.
- Verify no code path depends on mock data.
- Document unresolved real-world dependencies in README or module docs.
