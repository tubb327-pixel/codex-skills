---
name: solana-trading-system
description: Use when the task spans the whole Solana trading stack or when multiple lower-level skills would otherwise need to be coordinated together. This is the umbrella skill for repo bootstrap, architecture, Anchor guardrails, off-chain execution, routing, detection, and ops.
---

# Purpose
Coordinate end-to-end work across the full Solana trading system.

# Covers
- repository bootstrap and crate layout
- architecture boundaries
- Anchor program controls
- off-chain executor implementation
- Jupiter integration
- Pump.fun or launch-event detection
- risk policy and operational safety
- testing and verification workflow

# Activation rule
Use this skill when the user asks for a full system, repo scaffold, multi-phase buildout, or major refactor.

# Output shape
1. phase plan
2. crates/files to create or modify
3. dependencies on live external systems
4. unresolved unknowns isolated behind interfaces
5. validation checklist

# Coordination rule
When active, explicitly pull in the relevant lower-level skills rather than solving everything in one undifferentiated pass.
