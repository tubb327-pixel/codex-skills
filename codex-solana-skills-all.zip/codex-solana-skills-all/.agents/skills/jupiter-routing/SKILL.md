---
name: jupiter-routing
description: Use when integrating Jupiter for quote retrieval, route selection, swap transaction preparation, or adapter design inside a Solana trading executor. Do not use for non-routing tasks or generic Anchor account work.
---

# Purpose
Integrate Jupiter cleanly without leaking aggregator-specific assumptions across the system.

# Integration pattern
- create a routing adapter trait
- isolate quote request/response parsing
- normalize route outputs into internal execution intent
- validate expected slippage and token mint assumptions before submission

# Output expectations
For implementation tasks, include:
- routing trait/interface
- config surface
- quote normalization model
- error taxonomy
- retry/circuit-breaker behavior

# Safety rules
- Never assume schema stability without versioning.
- Never bypass on-chain risk checks because the router returned a route.
- Keep aggregator-specific code isolated from strategy logic.
