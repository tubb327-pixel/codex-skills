---
name: anchor-program-guardrails
description: Use when implementing or reviewing the on-chain Anchor program for a Solana trading system, especially for config accounts, vault PDAs, executor authorization, risk checks, and emergency controls. Do not use for off-chain market ingestion or routing logic.
---

# Purpose
Implement the on-chain control plane and guardrails.

# The program should own
- global config / strategy state
- authorized executors list
- vault PDAs and token accounts where applicable
- risk and trade accounting state

# Enforce on-chain where possible
- max position size
- cooldown windows
- slippage ceiling
- daily loss cap
- emergency stop / kill switch
- executor authorization

# Implementation rules
- Prefer explicit account validation.
- Keep account sizes compact and documented.
- Avoid storing bulky histories; store only compact state needed for enforcement.
- Emit events for critical transitions if helpful.
- Separate instruction handlers from validation helpers.

# Review checklist
- Can an unauthorized signer bypass execution?
- Can stale state break daily loss accounting?
- Can slippage limits be bypassed through malformed inputs?
- Can vault authority escape PDAs?
- Can emergency stop halt all trade paths?
