---
name: testing-and-verification
description: Use when defining or implementing compile checks, linting, unit tests, integration tests, local validator workflows, and verification criteria for the Solana trading system.
---

# Purpose
Make the repo verifiable without pretending live dependencies exist when they do not.

# Include
- format and lint commands
- crate-level unit tests
- integration tests that do not rely on mock market data for production logic
- local validator workflow where appropriate
- explicit separation between deterministic tests and live-environment tests

# Rules
- Do not call simulated market data “realistic enough”.
- It is acceptable to leave live integration tests gated behind environment requirements.
- State exactly what cannot be verified without live credentials or live endpoints.
