---
name: risk-and-ops
description: Use when the task involves risk policy, trading limits, failure handling, circuit breakers, observability, or operational readiness for a Solana trading system. Do not use for isolated UI or documentation-only work.
---

# Purpose
Keep the system alive, bounded, and debuggable.

# Cover these areas
- position limits
- daily drawdown limits
- kill switches
- cooldowns
- degraded-mode behavior
- RPC failover
- metrics and alerting hooks
- reconciliation and audit trails

# Operational expectations
- every external call has timeout and error classification
- every order path has deterministic logging context
- every irreversible action has a precondition checklist
- every emergency control has a test path

# Deliverables
When asked for an ops/risk plan, produce:
1. policy list
2. enforcement location (on-chain vs off-chain)
3. trigger conditions
4. recovery procedure
5. telemetry needed to prove it works
