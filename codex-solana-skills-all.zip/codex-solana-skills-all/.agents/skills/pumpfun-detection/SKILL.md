---
name: pumpfun-detection
description: Use when implementing Pump.fun or similar launch-event detection, mint discovery, initial filtering, and ultra-low-latency candidate evaluation from live Solana data. Do not use for post-trade accounting or general repository setup.
---

# Purpose
Detect new opportunities from live chain activity with strict skepticism.

# Expected pipeline
- subscribe to relevant logs/accounts
- identify candidate mints or pools
- enrich with real liquidity / metadata / holder signals
- score quickly
- reject unsafe candidates early
- hand off only valid candidates to execution

# Required rules
- Use live sources only.
- Mark any missing real-time source as `UNIMPLEMENTED_UNTIL_REAL_SOURCE_CONNECTED`.
- Distinguish detection, enrichment, scoring, and execution handoff.
- Add per-stage latency logging.

# Risk heuristics to encode outside the program
- creator concentration
- liquidity weakness
- suspicious holder distribution
- missing metadata or malformed mint state
- insufficient route quality
