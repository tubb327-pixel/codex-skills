---
name: offchain-executor
description: Use when building the Rust off-chain executor for Solana trading: endpoint wiring, stream ingestion, signal evaluation, transaction assembly, retries, confirmation tracking, and reconciliation. Do not use for pure on-chain account modeling.
---

# Purpose
Build the executor that turns live data into signed program invocations.

# Core responsibilities
- connect to Solana RPC and WebSocket endpoints
- ingest live pool, trade, and account events
- normalize external data
- compute candidate trades
- call routing/execution adapters
- invoke the Anchor program
- track signatures, confirmations, fills, and failures

# Required engineering patterns
- Use typed config loaded from env/files.
- Use backoff and retry policy for network operations.
- Separate ingestion, decision, and execution modules.
- Add structured logs and metrics hooks.
- Make external dependencies swappable behind traits.

# No-go patterns
- no hardcoded secrets
- no fake market snapshots
- no silent retry loops
- no direct business logic inside transport clients
