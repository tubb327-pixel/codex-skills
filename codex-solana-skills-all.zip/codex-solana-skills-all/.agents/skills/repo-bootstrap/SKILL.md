---
name: repo-bootstrap
description: Use when creating the initial repository scaffold, crate structure, workspace files, environment template, and operational docs for a Solana trading project intended for Codex-driven implementation.
---

# Purpose
Create a clean starting point that Codex can safely extend.

# Expected outputs
- Cargo workspace layout
- Anchor program crate scaffold
- off-chain executor crate scaffold
- shared config/types crate if useful
- `.env.example`
- README with real dependency checklist
- scripts or Make targets for fmt, clippy, build, and test

# Rules
- Separate on-chain and off-chain crates.
- Do not fake external services just to complete scaffolding.
- Prefer explicit placeholders over invented implementations.
