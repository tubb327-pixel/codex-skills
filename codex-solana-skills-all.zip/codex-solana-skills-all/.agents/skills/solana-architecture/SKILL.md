---
name: solana-architecture
description: Use when the task is to design or refactor the end-to-end architecture of a Solana trading system, especially when splitting responsibilities between an Anchor program and an off-chain executor. Do not use for narrow bugfixes or isolated syntax edits.
---

# Purpose
Design a production-grade Solana trading system with clear boundaries between on-chain enforcement and off-chain execution.

# Default target architecture
- Anchor program:
  - strategy config storage
  - authorized executor registry
  - vault PDA ownership
  - hard risk limits
  - compact trade and loss accounting
  - emergency stop
- Off-chain executor:
  - RPC and WebSocket connectivity
  - live market and pool ingestion
  - signal generation
  - route discovery
  - transaction building and submission
  - post-trade reconciliation

# Required output shape
When asked to design architecture, produce:
1. component list
2. data flow
3. failure domains
4. trust boundaries
5. latency-sensitive paths
6. files/crates layout
7. open unknowns

# Constraints
- Push irreversible risk checks on-chain.
- Keep exchange-specific logic out of the Anchor program.
- Use traits/adapters for external integrations.
- If real-world schemas are unknown, define interfaces only and mark exact wiring as pending.
