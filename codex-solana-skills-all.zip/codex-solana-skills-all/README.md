# Codex-ready Solana skills pack

This pack converts the full Solana trading skill set into a Codex-friendly repository layout.

## Included
- `AGENTS.md` for repository-level behavior
- `.agents/skills/*/SKILL.md` for explicit and implicit skill activation
- `.codex/config.toml` as a minimal project config stub
- `codex-bootstrap-prompt.md` for first-run orchestration

## Skill inventory
- `solana-trading-system` (umbrella orchestrator)
- `repo-bootstrap`
- `solana-architecture`
- `anchor-program-guardrails`
- `offchain-executor`
- `jupiter-routing`
- `pumpfun-detection`
- `risk-and-ops`
- `testing-and-verification`

## Install
Copy these files into the root of the target repository, then start Codex from that repository.

## Usage
Ask Codex to follow `AGENTS.md` and activate the matching skills under `.agents/skills`.
