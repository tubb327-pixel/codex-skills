# Solana Trader Scaffold

A two-component Solana trading system scaffold in Rust:

1. `programs/solana_trader`: a single Anchor on-chain program for custody, authorization, and hard risk controls.
2. `executor`: an off-chain Rust process that connects to Solana RPC/WebSocket endpoints, ingests live events, asks Jupiter for quotes/instructions, and submits transactions to the on-chain program.

## Jupiter option B status

This repo is now patched for the **PDA/vault-first Jupiter path**:

- on-chain `TradeIntent` account added
- on-chain `prepare_trade_intent` gating added
- `execute_trade` now consumes a prepared intent
- executor-side Jupiter client added for `quote` and `swap-instructions`
- executor transaction flow split into:
  1. prepare trade intent
  2. fetch Jupiter instructions
  3. compose/simulate/send execution transaction

## Important limitation

This patch gets the **Option B control plane** in place, but it does **not yet** complete true Jupiter CPI vault execution. Jupiter’s docs are explicit that for custom on-chain program integrations, CPI is now the recommended path for most users, while the Metis API also supports instruction-level control through `swap-instructions`. The current scaffold uses the Metis control path to fetch routes/instructions and wires your Anchor intent gate in front of execution. The next step is the actual Jupiter CPI account plumbing from PDA-owned source/destination token accounts if you want full vault-native execution. citeturn0search0turn0search1turn0search3turn0search4

## Notes

- PDAs are deterministic addresses controlled by the program, and the program can sign for them via `invoke_signed`. That is the correct model for vault authority and program-controlled token transfers. citeturn645099search0turn645099search4turn645099search24
- The executor should use Solana RPC/WebSocket subscriptions such as `logsSubscribe`, `programSubscribe`, `accountSubscribe`, `slotSubscribe`, and `signatureSubscribe` for live monitoring and reconciliation. citeturn645099search2turn645099search5turn645099search11turn645099search14turn645099search17turn645099search23
- Anchor account constraints and canonical bump handling are used for PDA safety. citeturn645099search6turn645099search19
