use anchor_lang::{
    prelude::*,
    solana_program::{instruction::{AccountMeta, Instruction}, program::invoke_signed},
};
use anchor_spl::token::{self, Mint, Token, TokenAccount, TransferChecked};

declare_id!("Trdr1111111111111111111111111111111111111");
pub const JUPITER_V6_PROGRAM_ID: Pubkey = pubkey!("JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4");

const GLOBAL_CONFIG_SEED: &[u8] = b"config";
const STRATEGY_STATE_SEED: &[u8] = b"strategy";
const VAULT_AUTH_SEED: &[u8] = b"vault_auth";
const VAULT_TOKEN_SEED: &[u8] = b"vault_token";
const POSITION_STATE_SEED: &[u8] = b"position";
const TRADE_INTENT_SEED: &[u8] = b"trade_intent";

#[program]
pub mod solana_trader {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>, params: InitializeParams) -> Result<()> {
        require!(params.max_position_size > 0, TraderError::InvalidConfig);
        require!(params.max_open_positions > 0, TraderError::InvalidConfig);

        let config = &mut ctx.accounts.global_config;
        config.admin = ctx.accounts.admin.key();
        config.authorized_executor = params.authorized_executor;
        config.paused = false;
        config.max_position_size = params.max_position_size;
        config.max_open_positions = params.max_open_positions;
        config.cooldown_secs = params.cooldown_secs;
        config.slippage_bps = params.slippage_bps;
        config.daily_loss_cap_quote = params.daily_loss_cap_quote;
        config.quote_mint = params.quote_mint;
        config.bump = ctx.bumps.global_config;
        config.vault_auth_bump = ctx.bumps.vault_authority;
        Ok(())
    }

    pub fn create_strategy(
        ctx: Context<CreateStrategy>,
        params: CreateStrategyParams,
    ) -> Result<()> {
        let strategy = &mut ctx.accounts.strategy_state;
        strategy.strategy_id = params.strategy_id;
        strategy.open_positions = 0;
        strategy.realized_pnl_day_quote = 0;
        strategy.last_trade_ts = 0;
        strategy.day_index = current_day_index(Clock::get()?.unix_timestamp);
        strategy.emergency_stop = false;
        strategy.seq_no = 0;
        strategy.bump = ctx.bumps.strategy_state;
        Ok(())
    }

    pub fn create_vault(ctx: Context<CreateVault>) -> Result<()> {
        let _ = &ctx.accounts;
        Ok(())
    }

    pub fn update_config(ctx: Context<UpdateConfig>, params: UpdateConfigParams) -> Result<()> {
        let config = &mut ctx.accounts.global_config;
        if let Some(executor) = params.authorized_executor {
            config.authorized_executor = executor;
        }
        if let Some(max_position_size) = params.max_position_size {
            require!(max_position_size > 0, TraderError::InvalidConfig);
            config.max_position_size = max_position_size;
        }
        if let Some(max_open_positions) = params.max_open_positions {
            require!(max_open_positions > 0, TraderError::InvalidConfig);
            config.max_open_positions = max_open_positions;
        }
        if let Some(cooldown_secs) = params.cooldown_secs {
            config.cooldown_secs = cooldown_secs;
        }
        if let Some(slippage_bps) = params.slippage_bps {
            config.slippage_bps = slippage_bps;
        }
        if let Some(daily_loss_cap_quote) = params.daily_loss_cap_quote {
            config.daily_loss_cap_quote = daily_loss_cap_quote;
        }
        Ok(())
    }

    pub fn set_pause(ctx: Context<AdminOnly>, paused: bool) -> Result<()> {
        ctx.accounts.global_config.paused = paused;
        emit!(PauseStateChanged { paused });
        Ok(())
    }

    pub fn emergency_stop(ctx: Context<AdminOnly>, stop: bool) -> Result<()> {
        ctx.accounts.strategy_state.emergency_stop = stop;
        emit!(EmergencyStopChanged {
            strategy_id: ctx.accounts.strategy_state.strategy_id,
            emergency_stop: stop,
        });
        Ok(())
    }

    pub fn deposit_quote(ctx: Context<DepositQuote>, amount: u64) -> Result<()> {
        require!(amount > 0, TraderError::InvalidAmount);
        let cpi_accounts = TransferChecked {
            from: ctx.accounts.depositor_quote_ata.to_account_info(),
            mint: ctx.accounts.quote_mint.to_account_info(),
            to: ctx.accounts.vault_quote_ata.to_account_info(),
            authority: ctx.accounts.depositor.to_account_info(),
        };
        let cpi_ctx = CpiContext::new(ctx.accounts.token_program.to_account_info(), cpi_accounts);
        token::transfer_checked(cpi_ctx, amount, ctx.accounts.quote_mint.decimals)?;
        Ok(())
    }

    pub fn withdraw_quote(ctx: Context<WithdrawQuote>, amount: u64) -> Result<()> {
        require!(amount > 0, TraderError::InvalidAmount);
        let global_key = ctx.accounts.global_config.key();
        let seeds: &[&[u8]] = &[
            VAULT_AUTH_SEED,
            global_key.as_ref(),
            &[ctx.accounts.global_config.vault_auth_bump],
        ];
        let signer_seeds: &[&[&[u8]]] = &[seeds];
        let cpi_accounts = TransferChecked {
            from: ctx.accounts.vault_quote_ata.to_account_info(),
            mint: ctx.accounts.quote_mint.to_account_info(),
            to: ctx.accounts.destination_quote_ata.to_account_info(),
            authority: ctx.accounts.vault_authority.to_account_info(),
        };
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            cpi_accounts,
            signer_seeds,
        );
        token::transfer_checked(cpi_ctx, amount, ctx.accounts.quote_mint.decimals)?;
        Ok(())
    }

    pub fn prepare_trade_intent(
        ctx: Context<PrepareTradeIntent>,
        params: PrepareTradeIntentParams,
    ) -> Result<()> {
        let clock = Clock::get()?;
        let config = &ctx.accounts.global_config;
        let strategy = &mut ctx.accounts.strategy_state;

        require!(!config.paused, TraderError::Paused);
        require!(!strategy.emergency_stop, TraderError::EmergencyStop);
        require_keys_eq!(
            ctx.accounts.executor.key(),
            config.authorized_executor,
            TraderError::UnauthorizedExecutor
        );
        require!(params.quote_in > 0, TraderError::InvalidAmount);
        require!(params.quote_in <= config.max_position_size, TraderError::PositionTooLarge);
        require!(params.slippage_bps <= config.slippage_bps, TraderError::SlippageTooHigh);
        require!(
            strategy.open_positions < config.max_open_positions,
            TraderError::TooManyOpenPositions
        );
        require!(
            clock.unix_timestamp >= strategy.last_trade_ts.saturating_add(config.cooldown_secs),
            TraderError::CooldownActive
        );

        let today = current_day_index(clock.unix_timestamp);
        if today != strategy.day_index {
            strategy.day_index = today;
            strategy.realized_pnl_day_quote = 0;
        }
        require!(
            strategy.realized_pnl_day_quote >= -(config.daily_loss_cap_quote as i64),
            TraderError::DailyLossCapExceeded
        );

        let intent = &mut ctx.accounts.trade_intent;
        intent.strategy = strategy.key();
        intent.executor = ctx.accounts.executor.key();
        intent.input_mint = params.input_mint;
        intent.output_mint = params.output_mint;
        intent.quote_in = params.quote_in;
        intent.min_out = params.min_out;
        intent.slippage_bps = params.slippage_bps;
        intent.expires_at = params.expires_at;
        intent.nonce = params.nonce;
        intent.status = TradeIntentStatus::Prepared as u8;
        intent.bump = ctx.bumps.trade_intent;

        emit!(TradeIntentPrepared {
            strategy_id: strategy.strategy_id,
            nonce: params.nonce,
            input_mint: params.input_mint,
            output_mint: params.output_mint,
            quote_in: params.quote_in,
            min_out: params.min_out,
        });
        Ok(())
    }

    pub fn execute_trade(ctx: Context<ExecuteTrade>, params: ExecuteTradeParams) -> Result<()> {
        let clock = Clock::get()?;
        let config = &ctx.accounts.global_config;
        let strategy = &mut ctx.accounts.strategy_state;

        require!(!config.paused, TraderError::Paused);
        require!(!strategy.emergency_stop, TraderError::EmergencyStop);
        require_keys_eq!(
            ctx.accounts.executor.key(),
            config.authorized_executor,
            TraderError::UnauthorizedExecutor
        );
        require!(params.size_quote > 0, TraderError::InvalidAmount);
        require!(params.size_quote <= config.max_position_size, TraderError::PositionTooLarge);
        require!(params.slippage_bps <= config.slippage_bps, TraderError::SlippageTooHigh);
        require!(
            strategy.open_positions < config.max_open_positions,
            TraderError::TooManyOpenPositions
        );
        require!(
            clock.unix_timestamp >= strategy.last_trade_ts.saturating_add(config.cooldown_secs),
            TraderError::CooldownActive
        );

        let today = current_day_index(clock.unix_timestamp);
        if today != strategy.day_index {
            strategy.day_index = today;
            strategy.realized_pnl_day_quote = 0;
        }
        require!(
            strategy.realized_pnl_day_quote >= -(config.daily_loss_cap_quote as i64),
            TraderError::DailyLossCapExceeded
        );

        let intent = &mut ctx.accounts.trade_intent;
        require!(intent.status == TradeIntentStatus::Prepared as u8, TraderError::IntentNotPrepared);
        require_keys_eq!(intent.executor, ctx.accounts.executor.key(), TraderError::UnauthorizedExecutor);
        require_keys_eq!(intent.input_mint, params.input_mint, TraderError::IntentMismatch);
        require_keys_eq!(intent.output_mint, params.base_mint, TraderError::IntentMismatch);
        require!(params.size_quote <= intent.quote_in, TraderError::IntentMismatch);
        require!(clock.unix_timestamp <= intent.expires_at, TraderError::IntentExpired);
        require_keys_eq!(params.jupiter_program, JUPITER_V6_PROGRAM_ID, TraderError::InvalidJupiterProgram);
        require_keys_eq!(ctx.accounts.jupiter_program.key(), JUPITER_V6_PROGRAM_ID, TraderError::InvalidJupiterProgram);
        require_keys_eq!(ctx.accounts.vault_input_ata.mint, params.input_mint, TraderError::VaultMintMismatch);
        require_keys_eq!(ctx.accounts.vault_output_ata.mint, params.base_mint, TraderError::VaultMintMismatch);
        require_keys_eq!(ctx.accounts.vault_input_ata.owner, ctx.accounts.vault_authority.key(), TraderError::VaultAuthorityMismatch);
        require_keys_eq!(ctx.accounts.vault_output_ata.owner, ctx.accounts.vault_authority.key(), TraderError::VaultAuthorityMismatch);

        require!(
            params.jupiter_accounts.iter().any(|m| m.pubkey == ctx.accounts.vault_input_ata.key() && m.is_writable),
            TraderError::MissingVaultInputAccount
        );
        require!(
            params.jupiter_accounts.iter().any(|m| m.pubkey == ctx.accounts.vault_output_ata.key() && m.is_writable),
            TraderError::MissingVaultOutputAccount
        );
        require!(
            params.jupiter_accounts.iter().any(|m| m.pubkey == ctx.accounts.vault_authority.key() && m.is_signer),
            TraderError::MissingVaultAuthoritySigner
        );

        let global_key = ctx.accounts.global_config.key();
        let signer_seeds: &[&[&[u8]]] = &[&[
            VAULT_AUTH_SEED,
            global_key.as_ref(),
            &[ctx.accounts.global_config.vault_auth_bump],
        ]];

        let inner_ix = Instruction {
            program_id: params.jupiter_program,
            accounts: params
                .jupiter_accounts
                .iter()
                .map(|a| {
                    if a.is_writable {
                        AccountMeta::new(a.pubkey, a.is_signer)
                    } else {
                        AccountMeta::new_readonly(a.pubkey, a.is_signer)
                    }
                })
                .collect(),
            data: params.jupiter_data.clone(),
        };

        let mut inner_infos = resolve_jupiter_account_infos(&ctx, &params.jupiter_accounts)?;
        inner_infos.push(ctx.accounts.jupiter_program.to_account_info());
        invoke_signed(&inner_ix, &inner_infos, signer_seeds)?;

        let position = &mut ctx.accounts.position_state;
        position.strategy = strategy.key();
        position.mint = params.base_mint;
        position.side = params.side;
        position.size_base = params.size_base;
        position.entry_quote_value = params.size_quote;
        position.opened_ts = clock.unix_timestamp;
        position.status = PositionStatus::Open as u8;
        position.bump = ctx.bumps.position_state;

        strategy.last_trade_ts = clock.unix_timestamp;
        strategy.open_positions = strategy.open_positions.saturating_add(1);
        strategy.seq_no = strategy.seq_no.saturating_add(1);
        intent.status = TradeIntentStatus::Consumed as u8;

        emit!(TradeExecuted {
            strategy_id: strategy.strategy_id,
            seq_no: strategy.seq_no,
            base_mint: params.base_mint,
            side: params.side,
            size_quote: params.size_quote,
            size_base: params.size_base,
            slippage_bps: params.slippage_bps,
        });
        Ok(())
    }

    pub fn close_position(ctx: Context<ClosePosition>, params: ClosePositionParams) -> Result<()> {
        let strategy = &mut ctx.accounts.strategy_state;
        let position = &mut ctx.accounts.position_state;

        require_keys_eq!(
            ctx.accounts.executor.key(),
            ctx.accounts.global_config.authorized_executor,
            TraderError::UnauthorizedExecutor
        );
        require!(position.status == PositionStatus::Open as u8, TraderError::PositionNotOpen);

        strategy.realized_pnl_day_quote = strategy
            .realized_pnl_day_quote
            .saturating_add(params.realized_pnl_quote_delta);
        strategy.open_positions = strategy.open_positions.saturating_sub(1);
        strategy.seq_no = strategy.seq_no.saturating_add(1);

        position.status = PositionStatus::Closed as u8;

        emit!(PositionClosed {
            strategy_id: strategy.strategy_id,
            seq_no: strategy.seq_no,
            mint: position.mint,
            realized_pnl_quote_delta: params.realized_pnl_quote_delta,
        });
        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(params: InitializeParams)]
pub struct Initialize<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(
        init,
        payer = admin,
        space = 8 + GlobalConfig::INIT_SPACE,
        seeds = [GLOBAL_CONFIG_SEED],
        bump,
    )]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(
        seeds = [VAULT_AUTH_SEED, global_config.key().as_ref()],
        bump,
    )]
    /// CHECK: PDA authority only.
    pub vault_authority: UncheckedAccount<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(params: CreateStrategyParams)]
pub struct CreateStrategy<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(
        has_one = admin @ TraderError::UnauthorizedAdmin,
        seeds = [GLOBAL_CONFIG_SEED],
        bump = global_config.bump,
    )]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(
        init,
        payer = admin,
        space = 8 + StrategyState::INIT_SPACE,
        seeds = [STRATEGY_STATE_SEED, &params.strategy_id.to_le_bytes()],
        bump,
    )]
    pub strategy_state: Account<'info, StrategyState>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreateVault<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    #[account(
        has_one = admin @ TraderError::UnauthorizedAdmin,
        seeds = [GLOBAL_CONFIG_SEED],
        bump = global_config.bump,
    )]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(
        seeds = [VAULT_AUTH_SEED, global_config.key().as_ref()],
        bump = global_config.vault_auth_bump,
    )]
    /// CHECK: PDA authority used for token CPI signing.
    pub vault_authority: UncheckedAccount<'info>,
    #[account(
        init,
        payer = admin,
        token::mint = token_mint,
        token::authority = vault_authority,
        seeds = [VAULT_TOKEN_SEED, global_config.key().as_ref(), token_mint.key().as_ref()],
        bump,
    )]
    pub vault_token_account: Account<'info, TokenAccount>,
    pub token_mint: Account<'info, Mint>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateConfig<'info> {
    pub admin: Signer<'info>,
    #[account(
        mut,
        has_one = admin @ TraderError::UnauthorizedAdmin,
        seeds = [GLOBAL_CONFIG_SEED],
        bump = global_config.bump,
    )]
    pub global_config: Account<'info, GlobalConfig>,
}

#[derive(Accounts)]
pub struct AdminOnly<'info> {
    pub admin: Signer<'info>,
    #[account(
        mut,
        has_one = admin @ TraderError::UnauthorizedAdmin,
        seeds = [GLOBAL_CONFIG_SEED],
        bump = global_config.bump,
    )]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(mut)]
    pub strategy_state: Account<'info, StrategyState>,
}

#[derive(Accounts)]
pub struct DepositQuote<'info> {
    #[account(mut)]
    pub depositor: Signer<'info>,
    #[account(seeds = [GLOBAL_CONFIG_SEED], bump = global_config.bump)]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(mut)]
    pub depositor_quote_ata: Account<'info, TokenAccount>,
    #[account(
        mut,
        seeds = [VAULT_TOKEN_SEED, global_config.key().as_ref(), quote_mint.key().as_ref()],
        bump,
    )]
    pub vault_quote_ata: Account<'info, TokenAccount>,
    #[account(address = global_config.quote_mint)]
    pub quote_mint: Account<'info, Mint>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct WithdrawQuote<'info> {
    pub admin: Signer<'info>,
    #[account(
        has_one = admin @ TraderError::UnauthorizedAdmin,
        seeds = [GLOBAL_CONFIG_SEED],
        bump = global_config.bump,
    )]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(
        seeds = [VAULT_AUTH_SEED, global_config.key().as_ref()],
        bump = global_config.vault_auth_bump,
    )]
    /// CHECK: PDA authority used for token CPI signing.
    pub vault_authority: UncheckedAccount<'info>,
    #[account(
        mut,
        seeds = [VAULT_TOKEN_SEED, global_config.key().as_ref(), quote_mint.key().as_ref()],
        bump,
    )]
    pub vault_quote_ata: Account<'info, TokenAccount>,
    #[account(mut)]
    pub destination_quote_ata: Account<'info, TokenAccount>,
    #[account(address = global_config.quote_mint)]
    pub quote_mint: Account<'info, Mint>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
#[instruction(params: PrepareTradeIntentParams)]
pub struct PrepareTradeIntent<'info> {
    #[account(mut)]
    pub executor: Signer<'info>,
    #[account(seeds = [GLOBAL_CONFIG_SEED], bump = global_config.bump)]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(
        mut,
        seeds = [STRATEGY_STATE_SEED, &strategy_state.strategy_id.to_le_bytes()],
        bump = strategy_state.bump,
    )]
    pub strategy_state: Account<'info, StrategyState>,
    #[account(
        init,
        payer = executor,
        space = 8 + TradeIntent::INIT_SPACE,
        seeds = [TRADE_INTENT_SEED, strategy_state.key().as_ref(), &params.nonce.to_le_bytes()],
        bump,
    )]
    pub trade_intent: Account<'info, TradeIntent>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(params: ExecuteTradeParams)]
pub struct ExecuteTrade<'info> {
    #[account(mut)]
    pub executor: Signer<'info>,
    #[account(seeds = [GLOBAL_CONFIG_SEED], bump = global_config.bump)]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(
        mut,
        seeds = [STRATEGY_STATE_SEED, &strategy_state.strategy_id.to_le_bytes()],
        bump = strategy_state.bump,
    )]
    pub strategy_state: Account<'info, StrategyState>,
    #[account(
        mut,
        seeds = [TRADE_INTENT_SEED, strategy_state.key().as_ref(), &trade_intent.nonce.to_le_bytes()],
        bump = trade_intent.bump,
    )]
    pub trade_intent: Account<'info, TradeIntent>,
    #[account(
        init,
        payer = executor,
        space = 8 + PositionState::INIT_SPACE,
        seeds = [POSITION_STATE_SEED, strategy_state.key().as_ref(), params.base_mint.as_ref(), &strategy_state.seq_no.to_le_bytes()],
        bump,
    )]
    pub position_state: Account<'info, PositionState>,
    #[account(
        seeds = [VAULT_AUTH_SEED, global_config.key().as_ref()],
        bump = global_config.vault_auth_bump,
    )]
    /// CHECK: PDA authority used for Jupiter CPI signer propagation.
    pub vault_authority: UncheckedAccount<'info>,
    #[account(
        mut,
        seeds = [VAULT_TOKEN_SEED, global_config.key().as_ref(), input_mint.key().as_ref()],
        bump,
    )]
    pub vault_input_ata: Account<'info, TokenAccount>,
    #[account(
        mut,
        seeds = [VAULT_TOKEN_SEED, global_config.key().as_ref(), output_mint.key().as_ref()],
        bump,
    )]
    pub vault_output_ata: Account<'info, TokenAccount>,
    pub input_mint: Account<'info, Mint>,
    pub output_mint: Account<'info, Mint>,
    #[account(address = JUPITER_V6_PROGRAM_ID)]
    /// CHECK: validated against known Jupiter V6 program id.
    pub jupiter_program: UncheckedAccount<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClosePosition<'info> {
    #[account(mut)]
    pub executor: Signer<'info>,
    #[account(seeds = [GLOBAL_CONFIG_SEED], bump = global_config.bump)]
    pub global_config: Account<'info, GlobalConfig>,
    #[account(mut)]
    pub strategy_state: Account<'info, StrategyState>,
    #[account(mut, has_one = strategy_state)]
    pub position_state: Account<'info, PositionState>,
}

#[account]
#[derive(InitSpace)]
pub struct GlobalConfig {
    pub admin: Pubkey,
    pub authorized_executor: Pubkey,
    pub paused: bool,
    pub max_position_size: u64,
    pub max_open_positions: u16,
    pub cooldown_secs: i64,
    pub slippage_bps: u16,
    pub daily_loss_cap_quote: u64,
    pub quote_mint: Pubkey,
    pub bump: u8,
    pub vault_auth_bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct StrategyState {
    pub strategy_id: u64,
    pub open_positions: u16,
    pub realized_pnl_day_quote: i64,
    pub last_trade_ts: i64,
    pub day_index: i32,
    pub emergency_stop: bool,
    pub seq_no: u64,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct TradeIntent {
    pub strategy: Pubkey,
    pub executor: Pubkey,
    pub input_mint: Pubkey,
    pub output_mint: Pubkey,
    pub quote_in: u64,
    pub min_out: u64,
    pub slippage_bps: u16,
    pub expires_at: i64,
    pub nonce: u64,
    pub status: u8,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct PositionState {
    pub strategy: Pubkey,
    pub mint: Pubkey,
    pub side: u8,
    pub size_base: u64,
    pub entry_quote_value: u64,
    pub opened_ts: i64,
    pub status: u8,
    pub bump: u8,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct InitializeParams {
    pub authorized_executor: Pubkey,
    pub max_position_size: u64,
    pub max_open_positions: u16,
    pub cooldown_secs: i64,
    pub slippage_bps: u16,
    pub daily_loss_cap_quote: u64,
    pub quote_mint: Pubkey,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct CreateStrategyParams {
    pub strategy_id: u64,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Default)]
pub struct UpdateConfigParams {
    pub authorized_executor: Option<Pubkey>,
    pub max_position_size: Option<u64>,
    pub max_open_positions: Option<u16>,
    pub cooldown_secs: Option<i64>,
    pub slippage_bps: Option<u16>,
    pub daily_loss_cap_quote: Option<u64>,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct PrepareTradeIntentParams {
    pub input_mint: Pubkey,
    pub output_mint: Pubkey,
    pub quote_in: u64,
    pub min_out: u64,
    pub slippage_bps: u16,
    pub expires_at: i64,
    pub nonce: u64,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct SerializedAccountMeta {
    pub pubkey: Pubkey,
    pub is_signer: bool,
    pub is_writable: bool,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct ExecuteTradeParams {
    pub input_mint: Pubkey,
    pub base_mint: Pubkey,
    pub side: u8,
    pub size_quote: u64,
    pub size_base: u64,
    pub slippage_bps: u16,
    pub jupiter_program: Pubkey,
    pub jupiter_accounts: Vec<SerializedAccountMeta>,
    pub jupiter_data: Vec<u8>,
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct ClosePositionParams {
    pub realized_pnl_quote_delta: i64,
}

#[event]
pub struct PauseStateChanged {
    pub paused: bool,
}

#[event]
pub struct EmergencyStopChanged {
    pub strategy_id: u64,
    pub emergency_stop: bool,
}

#[event]
pub struct TradeIntentPrepared {
    pub strategy_id: u64,
    pub nonce: u64,
    pub input_mint: Pubkey,
    pub output_mint: Pubkey,
    pub quote_in: u64,
    pub min_out: u64,
}

#[event]
pub struct TradeExecuted {
    pub strategy_id: u64,
    pub seq_no: u64,
    pub base_mint: Pubkey,
    pub side: u8,
    pub size_quote: u64,
    pub size_base: u64,
    pub slippage_bps: u16,
}

#[event]
pub struct PositionClosed {
    pub strategy_id: u64,
    pub seq_no: u64,
    pub mint: Pubkey,
    pub realized_pnl_quote_delta: i64,
}

#[error_code]
pub enum TraderError {
    #[msg("Unauthorized admin")]
    UnauthorizedAdmin,
    #[msg("Unauthorized executor")]
    UnauthorizedExecutor,
    #[msg("Program is paused")]
    Paused,
    #[msg("Emergency stop enabled")]
    EmergencyStop,
    #[msg("Position size too large")]
    PositionTooLarge,
    #[msg("Cooldown is active")]
    CooldownActive,
    #[msg("Slippage exceeds configured ceiling")]
    SlippageTooHigh,
    #[msg("Daily loss cap exceeded")]
    DailyLossCapExceeded,
    #[msg("Too many open positions")]
    TooManyOpenPositions,
    #[msg("Invalid config")]
    InvalidConfig,
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Position is not open")]
    PositionNotOpen,
    #[msg("Trade intent is not prepared")]
    IntentNotPrepared,
    #[msg("Trade intent mismatched")]
    IntentMismatch,
    #[msg("Trade intent expired")]
    IntentExpired,
    #[msg("Invalid Jupiter program id")]
    InvalidJupiterProgram,
    #[msg("Vault token mint mismatch")]
    VaultMintMismatch,
    #[msg("Vault token owner mismatch")]
    VaultAuthorityMismatch,
    #[msg("Jupiter account list is missing the writable input vault")]
    MissingVaultInputAccount,
    #[msg("Jupiter account list is missing the writable output vault")]
    MissingVaultOutputAccount,
    #[msg("Jupiter account list is missing the PDA authority signer")]
    MissingVaultAuthoritySigner,
    #[msg("Required Jupiter account was not forwarded in remaining accounts")]
    MissingJupiterAccount,
}

#[repr(u8)]
pub enum PositionStatus {
    Open = 1,
    Closed = 2,
}

#[repr(u8)]
pub enum TradeIntentStatus {
    Prepared = 1,
    Consumed = 2,
}

fn current_day_index(unix_ts: i64) -> i32 {
    (unix_ts / 86_400) as i32
}

fn resolve_jupiter_account_infos<'info>(
    ctx: &Context<'_, '_, '_, 'info, ExecuteTrade<'info>>,
    metas: &[SerializedAccountMeta],
) -> Result<Vec<AccountInfo<'info>>> {
    metas.iter().map(|meta| resolve_one_jupiter_account_info(ctx, &meta.pubkey)).collect()
}

fn resolve_one_jupiter_account_info<'info>(
    ctx: &Context<'_, '_, '_, 'info, ExecuteTrade<'info>>,
    key: &Pubkey,
) -> Result<AccountInfo<'info>> {
    let explicit = [
        ctx.accounts.executor.to_account_info(),
        ctx.accounts.global_config.to_account_info(),
        ctx.accounts.strategy_state.to_account_info(),
        ctx.accounts.trade_intent.to_account_info(),
        ctx.accounts.position_state.to_account_info(),
        ctx.accounts.vault_authority.to_account_info(),
        ctx.accounts.vault_input_ata.to_account_info(),
        ctx.accounts.vault_output_ata.to_account_info(),
        ctx.accounts.input_mint.to_account_info(),
        ctx.accounts.output_mint.to_account_info(),
        ctx.accounts.token_program.to_account_info(),
        ctx.accounts.system_program.to_account_info(),
    ];

    if let Some(info) = explicit.into_iter().find(|info| info.key == key) {
        return Ok(info);
    }

    ctx.remaining_accounts
        .iter()
        .find(|info| info.key == key)
        .cloned()
        .ok_or(error!(TraderError::MissingJupiterAccount))
}
