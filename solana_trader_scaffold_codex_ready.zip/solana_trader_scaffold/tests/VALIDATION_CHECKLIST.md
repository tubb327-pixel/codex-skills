# Jupiter PDA + ALT Validation Checklist

Use this before you claim the Jupiter path is working.

## Environment
- [ ] `solana-test-validator` running
- [ ] `anchor build` succeeds
- [ ] IDL generated under `target/idl/solana_trader.json`
- [ ] local wallet funded
- [ ] executor wallet funded
- [ ] quote and base test mints created
- [ ] PDA vault ATAs created for both mints

## On-chain gates
- [ ] `initialize` succeeds with expected config
- [ ] unauthorized caller cannot `update_config`
- [ ] unauthorized caller cannot `set_pause`
- [ ] unauthorized caller cannot `withdraw_quote`
- [ ] unauthorized executor cannot `prepare_trade_intent`
- [ ] `prepare_trade_intent` fails when paused
- [ ] `prepare_trade_intent` fails when emergency stop is enabled
- [ ] `prepare_trade_intent` fails on oversize position
- [ ] `prepare_trade_intent` fails on excessive slippage
- [ ] `prepare_trade_intent` fails during cooldown
- [ ] `prepare_trade_intent` resets day bucket correctly when day changes

## Vault custody model
- [ ] quote vault ATA owner is vault authority PDA
- [ ] base vault ATA owner is vault authority PDA
- [ ] deposit moves quote into PDA vault
- [ ] admin-only withdraw moves quote back out
- [ ] vault mint checks reject mismatched vault accounts

## Jupiter CPI path
- [ ] executor fetches quote successfully
- [ ] executor fetches `swap-instructions` successfully
- [ ] returned Jupiter program id matches the on-chain allowlist
- [ ] returned instruction set contains no unsupported setup/cleanup path for this scaffold
- [ ] outer tx compiles as v0 message when ALT addresses are present
- [ ] lookup table accounts load successfully
- [ ] tx simulation passes before send
- [ ] on-chain `execute_trade` accepts the embedded Jupiter instruction
- [ ] `TradeIntent` status changes from Prepared to Consumed
- [ ] `PositionState` becomes Open
- [ ] `seq_no` increments
- [ ] input vault balance decreases
- [ ] output vault balance increases

## Failure-path checks
- [ ] stale intent expiry is rejected
- [ ] nonce replay is rejected or rendered inert by consumed status
- [ ] invalid Jupiter program id is rejected
- [ ] missing vault input account in Jupiter metas is rejected
- [ ] missing vault output account in Jupiter metas is rejected
- [ ] missing vault authority signer in Jupiter metas is rejected
- [ ] slippage above ceiling is rejected
- [ ] emergency stop blocks `execute_trade`
- [ ] pause blocks `execute_trade`

## Exit path
- [ ] `close_position` updates realized PnL
- [ ] `close_position` decrements open positions
- [ ] daily loss cap blocks new intents after threshold breach

## Acceptance bar
Do **not** call this production-ready until every non-skipped box above is proven on localnet first, then repeated on devnet/sandbox with the real executor flow.
