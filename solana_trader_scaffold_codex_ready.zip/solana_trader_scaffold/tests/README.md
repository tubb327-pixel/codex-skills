Integration test scaffolding for the Jupiter PDA + ALT flow.

Files:
- `jupiter_pda_alt.ts`: localnet Anchor/TS scaffold that validates config, strategy, vault setup, deposit flow, unauthorized executor rejection, trade intent creation, and ALT creation.
- `VALIDATION_CHECKLIST.md`: concrete acceptance checklist for the full Jupiter PDA/vault execution path.

Run with:
- `scripts/test_jupiter_localnet.sh`

Blunt caveat:
- the TypeScript test file validates the control plane and ALT plumbing scaffold.
- the actual live Jupiter swap execution path remains a manual acceptance step until you wire funded route pairs and run the Rust executor end to end on a validator/devnet environment.


## Added one-shot E2E path

Use `scripts/test_jupiter_e2e_dry_run.sh` for a deterministic Jupiter PDA + ALT dry-run path before moving to live submit mode. See `tests/JUPITER_E2E.md`.
