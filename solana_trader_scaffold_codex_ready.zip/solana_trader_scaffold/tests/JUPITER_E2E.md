# Jupiter PDA + ALT E2E Dry-Run Path

This is the first deterministic end-to-end validation path for the Jupiter PDA custody flow.

## What it validates

- the on-chain Anchor program accounts are present
- the PDA input/output vault token accounts exist
- Jupiter quote retrieval works
- Jupiter `swap-instructions` retrieval works
- ALT addresses from Jupiter can be fetched from RPC
- `prepare_trade_intent` simulates cleanly
- the outer v0 transaction with Anchor + Jupiter CPI simulates cleanly

## What it does **not** prove

- a confirmed live swap on-chain, unless you run with `--submit`
- SOL wrapping/unwrapping routes
- routes requiring Jupiter `setupInstructions`, `cleanupInstruction`, or `tokenLedgerInstruction`

## Required preconditions

- `PROGRAM_ID` points to your deployed Anchor program
- `SOLANA_HTTP_RPC` and `SOLANA_WS_RPC` point at a cluster where Jupiter routes are valid
- `QUOTE_MINT` is the same mint your on-chain config was initialized with
- `global_config`, `strategy_state`, and both PDA vault token accounts already exist
- the input vault contains enough balance for the requested amount

## Example

```bash
./scripts/test_jupiter_e2e_dry_run.sh \
  EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v \
  So11111111111111111111111111111111111111112 \
  1000000 \
  1 \
  42
```

## Submit mode

The one-shot binary supports real submission:

```bash
cargo run -p executor --bin jupiter_e2e_once -- \
  --strategy-id 1 \
  --input-mint <INPUT_MINT> \
  --output-mint <OUTPUT_MINT> \
  --amount <RAW_AMOUNT> \
  --nonce 42 \
  --submit
```

Use submit mode only after the dry-run path simulates cleanly.
