# Solana Trader Architecture

## Goal

Build a Solana trading system in Rust with:
- a single on-chain Anchor program for custody, authorization, and hard risk controls
- an off-chain Rust executor for market ingestion, signal generation, transaction composition, simulation, and submission
- Jupiter as the first execution venue using PDA/vault custody and versioned transactions with address lookup tables when needed

## Current Scope

This repo is focused on the first venue path only:
- Jupiter quote
- Jupiter `swap-instructions`
- Anchor trade-intent gating
- PDA-owned source/destination vault token accounts
- outer v0 transaction support with ALT loading
- one-shot E2E dry-run harness

This is not yet a production-ready multi-venue bot.

## Component Model

```text
┌────────────────────────────────────────────────────────────┐
│                    Off-chain Rust Executor                 │
│------------------------------------------------------------│
│ config / env                                               │
│ RPC + WebSocket clients                                    │
│ market data ingestion                                      │
│ signal generation                                          │
│ off-chain risk prechecks                                   │
│ Jupiter quote + swap-instructions                          │
│ transaction builder                                        │
│ simulator / sender / reconciler                            │
└──────────────────────────────┬─────────────────────────────┘
                               │
                               │ Anchor ix + Jupiter CPI path
                               ▼
┌────────────────────────────────────────────────────────────┐
│                 On-chain Anchor Program                    │
│------------------------------------------------------------│
│ GlobalConfig                                               │
│ StrategyState                                              │
│ TradeIntent                                                │
│ PositionState                                              │
│ PDA vault authority                                        │
│ PDA-owned token vault accounts                             │
│ authorization, cooldown, size limits, slippage checks      │
│ daily loss cap, pause, emergency stop                      │
└──────────────────────────────┬─────────────────────────────┘
                               │
                               ▼
┌────────────────────────────────────────────────────────────┐
│                 Token program / Jupiter CPI                │
└────────────────────────────────────────────────────────────┘
```

## Trust Boundary

### On-chain
The Anchor program is the trust anchor. It must enforce:
- authorized executor only
- strategy pause / emergency stop
- max position size
- cooldown
- slippage ceiling
- daily realized loss cap
- nonce freshness / replay resistance
- deterministic PDA custody

### Off-chain
The executor is allowed to be smart, but not trusted with guardrails. It can:
- watch markets
- compute signals
- ask Jupiter for quotes
- choose candidate routes
- build transactions
- simulate and send

It must not be the sole authority for hard risk constraints.

## Account Model

### PDAs
Suggested seeds:
- `config`
- `strategy:{strategy_id}`
- `vault_auth:{strategy_id}`
- `vault_token:{strategy_id}:{mint}`
- `trade_intent:{strategy_id}:{nonce}`
- `position:{strategy_id}:{mint}`

### Core Accounts
- `GlobalConfig`
  - admin
  - authorized executor or authority root
  - paused
  - quote mint
  - max position size
  - max open positions
  - cooldown secs
  - slippage bps ceiling
  - daily loss cap
  - bumps
- `StrategyState`
  - strategy id
  - open position count
  - realized pnl day
  - last trade ts
  - current day index
  - emergency stop flag
  - sequence / nonce state
- `TradeIntent`
  - executor
  - input mint
  - output mint
  - amount in
  - min out / slippage bound
  - expiry
  - used flag
- `PositionState`
  - mint
  - side
  - base size
  - quote entry value
  - opened ts
  - status

## Jupiter Execution Flow

```text
1. Executor loads on-chain config and strategy state
2. Executor computes a candidate trade from signal output
3. Executor requests a Jupiter quote
4. Executor rejects bad routes off-chain
5. Executor creates a TradeIntent on-chain
6. Executor requests Jupiter swap-instructions
7. Executor loads returned ALT accounts from RPC
8. Executor builds a v0 transaction
9. Outer transaction invokes Anchor execute_trade
10. Anchor validates intent + guardrails
11. Anchor CPIs into Jupiter with PDA signer and vault accounts
12. Executor simulates, then optionally submits
13. Executor reconciles result and records telemetry
```

## Why This Split Exists

Solana programs do not autonomously wake up, ingest market data, or decide to trade. Programs execute only when invoked by a transaction, so adaptive trading requires an off-chain process to watch the market and submit transactions. Jupiter also provides quote and swap-instructions APIs for route discovery and composable execution, while Solana versioned transactions and ALTs are the right fit for account-heavy routes. citeturn508508search6turn508508search17

## Repository Map

```text
.
├── Anchor.toml
├── Cargo.toml
├── ARCHITECTURE.md
├── CODEX_HANDOFF.md
├── CODEX_PROMPT.md
├── README.md
├── executor/
│   ├── Cargo.toml
│   └── src/
│       ├── bin/jupiter_e2e_once.rs
│       ├── config.rs
│       ├── error.rs
│       ├── jupiter.rs
│       ├── main.rs
│       ├── market_data.rs
│       ├── rpc.rs
│       ├── signal.rs
│       ├── state.rs
│       ├── tx_builder.rs
│       └── ws.rs
├── programs/
│   └── solana_trader/
│       ├── Cargo.toml
│       └── src/lib.rs
├── scripts/
│   ├── build.sh
│   ├── deploy_localnet.sh
│   ├── init_strategy.sh
│   ├── run_executor.sh
│   ├── test_jupiter_e2e_dry_run.sh
│   └── test_jupiter_localnet.sh
└── tests/
    ├── JUPITER_E2E.md
    ├── README.md
    ├── VALIDATION_CHECKLIST.md
    └── jupiter_pda_alt.ts
```

## Definition of Done for Jupiter Phase

The Jupiter phase is done only when all of these are true:
- `cargo check --workspace` passes
- `anchor build` passes
- TypeScript/Anchor tests pass locally
- one-shot dry-run path simulates cleanly against a live Jupiter-compatible cluster
- PDA vault token accounts are used as actual source/destination custody
- v0 transaction path works with loaded ALTs
- unauthorized executor path fails
- cooldown / size / slippage / pause checks fail when expected
- at least one real submit path confirms cleanly on a supported cluster

## Non-Goals for This Phase

Not part of the current phase:
- Raydium direct path
- Pump.fun migration watchers
- wallet-follow logic
- multi-venue arbitration
- advanced portfolio management
- full production observability and secrets hardening
