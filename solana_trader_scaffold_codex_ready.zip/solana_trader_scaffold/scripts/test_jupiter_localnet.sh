#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

need() {
  command -v "$1" >/dev/null 2>&1 || { echo "Missing required command: $1" >&2; exit 1; }
}

need solana
need anchor
need cargo
need npm

if ! solana cluster-version >/dev/null 2>&1; then
  echo "Solana RPC is not reachable. Start local validator first." >&2
  exit 1
fi

echo "==> Installing JS test dependencies"
npm install

echo "==> Building Anchor program"
anchor build

echo "==> Running TypeScript localnet scaffolding tests"
TS_NODE_TRANSPILE_ONLY=1 npx mocha -r ts-node/register -t 1000000 tests/jupiter_pda_alt.ts

echo
echo "==> Manual checklist"
echo "Review: tests/VALIDATION_CHECKLIST.md"
