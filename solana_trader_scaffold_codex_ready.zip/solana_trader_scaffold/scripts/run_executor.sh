#!/usr/bin/env bash
set -euo pipefail

export RUST_LOG=${RUST_LOG:-info}
source .env
cargo run -p executor -- --strategy-id 1 --observed-program 11111111111111111111111111111111 --dry-run
