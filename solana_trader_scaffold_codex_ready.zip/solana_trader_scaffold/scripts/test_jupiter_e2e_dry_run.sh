#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 3 ]]; then
  echo "usage: $0 <INPUT_MINT> <OUTPUT_MINT> <AMOUNT> [STRATEGY_ID] [NONCE]"
  exit 1
fi

INPUT_MINT="$1"
OUTPUT_MINT="$2"
AMOUNT="$3"
STRATEGY_ID="${4:-1}"
NONCE="${5:-0}"

cargo run -p executor --bin jupiter_e2e_once -- \
  --strategy-id "$STRATEGY_ID" \
  --input-mint "$INPUT_MINT" \
  --output-mint "$OUTPUT_MINT" \
  --amount "$AMOUNT" \
  --nonce "$NONCE"
