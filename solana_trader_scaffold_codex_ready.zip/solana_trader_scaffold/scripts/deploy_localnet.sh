#!/usr/bin/env bash
set -euo pipefail

solana-test-validator --reset > /tmp/solana-test-validator.log 2>&1 &
VALIDATOR_PID=$!
trap 'kill $VALIDATOR_PID || true' EXIT
sleep 5

solana config set --url localhost
anchor build
anchor deploy

wait
