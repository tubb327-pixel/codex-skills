#!/usr/bin/env bash
set -euo pipefail

cat <<'MSG'
Use an Anchor client or test harness to invoke:
1. initialize
2. create_strategy
3. create_vault
4. deposit_quote

This scaffold intentionally leaves the admin-side client generation open so you can choose:
- Anchor TS client
- Rust client with generated IDL bindings
- integration test harness
MSG
