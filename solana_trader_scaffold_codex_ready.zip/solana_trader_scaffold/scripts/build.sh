#!/usr/bin/env bash
set -euo pipefail

anchor build
cargo build -p executor
