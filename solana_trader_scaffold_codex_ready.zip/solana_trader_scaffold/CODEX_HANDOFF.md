# Codex Handoff

## Objective

Take this scaffold and turn the Jupiter PDA/vault path into a compile-tested, evidence-backed implementation.

## What Codex Should Do First

1. Inspect the repo and identify compile gaps.
2. Run the actual build/test commands.
3. Fix compile/runtime issues before adding scope.
4. Produce a short evidence log after each milestone.

## Mandatory Build Order

Run in this order:

```bash
cargo check --workspace
anchor build
npm install
anchor test --skip-local-validator
cargo run -p executor --bin jupiter_e2e_once -- --help
```

Then, if environment is available:

```bash
./scripts/test_jupiter_localnet.sh
./scripts/test_jupiter_e2e_dry_run.sh <INPUT_MINT> <OUTPUT_MINT> <AMOUNT> <STRATEGY_ID> <NONCE>
```

## Hard Rules

- Do not move to new modules until Jupiter works.
- Do not replace PDA custody with executor-wallet shortcuts.
- Do not silently weaken risk checks to make tests pass.
- Do not claim success without command output.
- Prefer small, reviewable commits/patches.

## Priority Fix Targets

### P0
- broken Rust/Anchor compilation
- account serialization mismatches
- PDA seed mismatches between executor and program
- incorrect Jupiter instruction/account forwarding
- v0 message / ALT loading failures

### P1
- flaky tests
- missing account setup scripts
- weak error surfaces
- missing environment validation

### P2
- cleanup/refactor
- improved metrics
- nicer operator UX

## Acceptance Gates

Codex should not mark Jupiter complete unless it can show evidence for:
- successful `cargo check --workspace`
- successful `anchor build`
- at least one passing local integration test
- successful dry-run simulation of the outer v0 Jupiter route
- explicit rejection tests for unauthorized executor and paused/emergency-stop conditions

## Expected Deliverables

- fixed repo code
- updated README with exact run order
- any new scripts needed for setup
- a concise `RESULTS.md` with command outputs and what passed/failed
