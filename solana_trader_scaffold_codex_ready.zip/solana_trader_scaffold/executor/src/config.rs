use std::{env, path::PathBuf, str::FromStr};

use anyhow::{Context, Result};
use solana_sdk::{commitment_config::CommitmentConfig, pubkey::Pubkey};

#[derive(Debug, Clone)]
pub struct AppConfig {
    pub http_rpc: String,
    pub ws_rpc: String,
    pub keypair_path: PathBuf,
    pub program_id: Pubkey,
    pub commitment: CommitmentConfig,
    pub quote_mint: Pubkey,
    pub trade_cooldown_secs: i64,
    pub slippage_bps: u16,
    pub max_signal_score: f64,
    pub jupiter_api_base: String,
    pub jupiter_api_key: Option<String>,
}

impl AppConfig {
    pub fn from_env() -> Result<Self> {
        let http_rpc = env::var("SOLANA_HTTP_RPC").context("SOLANA_HTTP_RPC not set")?;
        let ws_rpc = env::var("SOLANA_WS_RPC").context("SOLANA_WS_RPC not set")?;
        let keypair_path = PathBuf::from(
            env::var("SOLANA_KEYPAIR").context("SOLANA_KEYPAIR not set")?,
        );
        let program_id = Pubkey::from_str(&env::var("PROGRAM_ID").context("PROGRAM_ID not set")?)?;
        let quote_mint = Pubkey::from_str(&env::var("QUOTE_MINT").context("QUOTE_MINT not set")?)?;
        let commitment = match env::var("COMMITMENT").unwrap_or_else(|_| "confirmed".to_string()).as_str() {
            "processed" => CommitmentConfig::processed(),
            "finalized" => CommitmentConfig::finalized(),
            _ => CommitmentConfig::confirmed(),
        };
        let trade_cooldown_secs = env::var("TRADE_COOLDOWN_SECS")
            .unwrap_or_else(|_| "30".to_string())
            .parse()?;
        let slippage_bps = env::var("SLIPPAGE_BPS")
            .unwrap_or_else(|_| "100".to_string())
            .parse()?;
        let max_signal_score = env::var("MAX_SIGNAL_SCORE")
            .unwrap_or_else(|_| "100.0".to_string())
            .parse()?;
        let jupiter_api_base = env::var("JUPITER_API_BASE").unwrap_or_else(|_| "https://api.jup.ag".to_string());
        let jupiter_api_key = env::var("JUPITER_API_KEY").ok().filter(|s| !s.is_empty());

        Ok(Self {
            http_rpc,
            ws_rpc,
            keypair_path,
            program_id,
            commitment,
            quote_mint,
            trade_cooldown_secs,
            slippage_bps,
            max_signal_score,
            jupiter_api_base,
            jupiter_api_key,
        })
    }
}
