use anyhow::{Context, Result};
use anchor_lang::{InstructionData, ToAccountMetas};
use solana_sdk::{
    address_lookup_table_account::AddressLookupTableAccount,
    instruction::{AccountMeta, Instruction},
    message::{v0::Message as MessageV0, VersionedMessage},
    pubkey::Pubkey,
    signature::Keypair,
    signer::Signer,
    transaction::{Transaction, VersionedTransaction},
};
use solana_trader::{
    accounts as trader_accounts,
    instruction as trader_ix,
    ExecuteTradeParams, PrepareTradeIntentParams, SerializedAccountMeta,
};

use crate::{jupiter::InstructionPayload, state::SignalDecision};

pub struct TradeAccounts {
    pub global_config: Pubkey,
    pub strategy_state: Pubkey,
    pub trade_intent: Pubkey,
    pub position_state: Pubkey,
    pub vault_authority: Pubkey,
    pub vault_input_ata: Pubkey,
    pub vault_output_ata: Pubkey,
    pub input_mint: Pubkey,
    pub output_mint: Pubkey,
    pub jupiter_program: Pubkey,
}

pub fn build_prepare_trade_intent_transaction(
    payer: &Keypair,
    program_id: Pubkey,
    accounts: &TradeAccounts,
    params: PrepareTradeIntentParams,
    recent_blockhash: solana_sdk::hash::Hash,
) -> Result<Transaction> {
    let ix = Instruction {
        program_id,
        accounts: trader_accounts::PrepareTradeIntent {
            executor: payer.pubkey(),
            global_config: accounts.global_config,
            strategy_state: accounts.strategy_state,
            trade_intent: accounts.trade_intent,
            system_program: solana_sdk::system_program::id(),
        }
        .to_account_metas(None),
        data: trader_ix::PrepareTradeIntent { params }.data(),
    };

    Ok(Transaction::new_signed_with_payer(
        &[ix],
        Some(&payer.pubkey()),
        &[payer],
        recent_blockhash,
    ))
}

pub fn build_execute_trade_transaction(
    payer: &Keypair,
    program_id: Pubkey,
    accounts: &TradeAccounts,
    signal: &SignalDecision,
    compute_budget_payloads: &[InstructionPayload],
    jupiter_swap_payload: &InstructionPayload,
    lookup_tables: &[AddressLookupTableAccount],
    recent_blockhash: solana_sdk::hash::Hash,
) -> Result<VersionedTransaction> {
    let remaining_accounts = convert_jupiter_metas(&jupiter_swap_payload.accounts)?;

    let params = ExecuteTradeParams {
        input_mint: signal.input_mint,
        base_mint: signal.output_mint,
        side: signal.side,
        size_quote: signal.size_quote,
        size_base: signal.size_base_estimate,
        slippage_bps: 0,
        jupiter_program: jupiter_swap_payload.program_id.parse()?,
        jupiter_accounts: remaining_accounts.clone(),
        jupiter_data: decode_base64(&jupiter_swap_payload.data)?,
    };

    let mut account_metas = trader_accounts::ExecuteTrade {
        executor: payer.pubkey(),
        global_config: accounts.global_config,
        strategy_state: accounts.strategy_state,
        trade_intent: accounts.trade_intent,
        position_state: accounts.position_state,
        vault_authority: accounts.vault_authority,
        vault_input_ata: accounts.vault_input_ata,
        vault_output_ata: accounts.vault_output_ata,
        input_mint: accounts.input_mint,
        output_mint: accounts.output_mint,
        jupiter_program: accounts.jupiter_program,
        token_program: anchor_spl::token::ID,
        system_program: solana_sdk::system_program::id(),
    }
    .to_account_metas(None);

    account_metas.extend(remaining_accounts.iter().map(|meta| {
        if meta.is_writable {
            AccountMeta::new(meta.pubkey, meta.is_signer)
        } else {
            AccountMeta::new_readonly(meta.pubkey, meta.is_signer)
        }
    }));

    let anchor_ix = Instruction {
        program_id,
        accounts: account_metas,
        data: trader_ix::ExecuteTrade { params }.data(),
    };

    let mut instructions = compute_budget_payloads
        .iter()
        .map(deserialize_instruction)
        .collect::<Result<Vec<_>>>()?;
    instructions.push(anchor_ix);

    let message = MessageV0::try_compile(
        &payer.pubkey(),
        &instructions,
        lookup_tables,
        recent_blockhash,
    )
    .context("failed to compile v0 message")?;

    Ok(VersionedTransaction::try_new(
        VersionedMessage::V0(message),
        &[payer],
    )
    .context("failed to sign versioned tx")?)
}

pub fn deserialize_instruction(ix: &InstructionPayload) -> Result<Instruction> {
    let program_id = ix.program_id.parse()?;
    let accounts = ix
        .accounts
        .iter()
        .map(|a| {
            let pk = a.pubkey.parse()?;
            Ok(if a.is_writable {
                AccountMeta::new(pk, a.is_signer)
            } else {
                AccountMeta::new_readonly(pk, a.is_signer)
            })
        })
        .collect::<Result<Vec<_>>>()?;
    let data = decode_base64(&ix.data)?;
    Ok(Instruction { program_id, accounts, data })
}

fn convert_jupiter_metas(accounts: &[crate::jupiter::InstructionAccount]) -> Result<Vec<SerializedAccountMeta>> {
    accounts
        .iter()
        .map(|a| {
            Ok(SerializedAccountMeta {
                pubkey: a.pubkey.parse()?,
                is_signer: a.is_signer,
                is_writable: a.is_writable,
            })
        })
        .collect()
}

fn decode_base64(data: &str) -> Result<Vec<u8>> {
    use base64::Engine;
    base64::engine::general_purpose::STANDARD
        .decode(data)
        .context("invalid base64 instruction data")
}
