use anyhow::Result;
use solana_client::nonblocking::pubsub_client::PubsubClient;
use solana_rpc_client_api::config::{RpcTransactionLogsConfig, RpcTransactionLogsFilter};
use solana_sdk::commitment_config::CommitmentConfig;

pub async fn connect_logs(ws_url: &str, commitment: CommitmentConfig) -> Result<PubsubClient> {
    let client = PubsubClient::new(ws_url).await?;
    let _ = client
        .logs_subscribe(
            RpcTransactionLogsFilter::All,
            RpcTransactionLogsConfig {
                commitment: Some(commitment),
            },
        )
        .await?;
    Ok(client)
}
