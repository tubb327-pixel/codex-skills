use anyhow::{Context, Result};
use reqwest::header::{HeaderMap, HeaderValue};
use serde::{Deserialize, Serialize};
use solana_sdk::pubkey::Pubkey;

#[derive(Debug, Clone)]
pub struct JupiterClient {
    client: reqwest::Client,
    base_url: String,
}

impl JupiterClient {
    pub fn new(base_url: impl Into<String>, api_key: Option<&str>) -> Result<Self> {
        let mut headers = HeaderMap::new();
        if let Some(key) = api_key.filter(|k| !k.is_empty()) {
            headers.insert("x-api-key", HeaderValue::from_str(key)?);
        }
        let client = reqwest::Client::builder().default_headers(headers).build()?;
        Ok(Self {
            client,
            base_url: base_url.into(),
        })
    }

    pub async fn quote(
        &self,
        input_mint: Pubkey,
        output_mint: Pubkey,
        amount: u64,
        slippage_bps: u16,
        restrict_intermediate_tokens: bool,
        only_direct_routes: bool,
    ) -> Result<QuoteResponse> {
        let url = format!("{}/swap/v1/quote", self.base_url.trim_end_matches('/'));
        let response = self
            .client
            .get(url)
            .query(&[
                ("inputMint", input_mint.to_string()),
                ("outputMint", output_mint.to_string()),
                ("amount", amount.to_string()),
                ("slippageBps", slippage_bps.to_string()),
                (
                    "restrictIntermediateTokens",
                    restrict_intermediate_tokens.to_string(),
                ),
                ("onlyDirectRoutes", only_direct_routes.to_string()),
                ("instructionVersion", "V2".to_string()),
            ])
            .send()
            .await?
            .error_for_status()?
            .json::<QuoteResponse>()
            .await
            .context("failed to decode Jupiter quote response")?;
        Ok(response)
    }

    pub async fn swap_instructions(
        &self,
        request: &SwapInstructionsRequest,
    ) -> Result<SwapInstructionsResponse> {
        let url = format!("{}/swap/v1/swap-instructions", self.base_url.trim_end_matches('/'));
        let response = self
            .client
            .post(url)
            .json(request)
            .send()
            .await?
            .error_for_status()?
            .json::<SwapInstructionsResponse>()
            .await
            .context("failed to decode Jupiter swap-instructions response")?;
        Ok(response)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct QuoteResponse {
    pub input_mint: String,
    pub in_amount: String,
    pub output_mint: String,
    pub out_amount: String,
    pub other_amount_threshold: String,
    pub swap_mode: String,
    pub slippage_bps: u16,
    pub price_impact_pct: String,
    pub route_plan: Vec<RoutePlanStep>,
    pub context_slot: u64,
    pub time_taken: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RoutePlanStep {
    pub percent: u8,
    pub swap_info: SwapInfo,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SwapInfo {
    pub amm_key: String,
    pub label: String,
    pub input_mint: String,
    pub output_mint: String,
    pub in_amount: String,
    pub out_amount: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SwapInstructionsRequest {
    pub user_public_key: String,
    pub quote_response: QuoteResponse,
    pub dynamic_compute_unit_limit: bool,
    pub prioritization_fee_lamports: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SwapInstructionsResponse {
    pub token_ledger_instruction: Option<InstructionPayload>,
    pub compute_budget_instructions: Vec<InstructionPayload>,
    pub setup_instructions: Vec<InstructionPayload>,
    pub swap_instruction: InstructionPayload,
    pub cleanup_instruction: Option<InstructionPayload>,
    pub address_lookup_table_addresses: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InstructionPayload {
    pub program_id: String,
    pub accounts: Vec<InstructionAccount>,
    pub data: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InstructionAccount {
    pub pubkey: String,
    pub is_signer: bool,
    pub is_writable: bool,
}
