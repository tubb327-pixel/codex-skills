mod config;
mod error;
mod jupiter;
mod market_data;
mod rpc;
mod signal;
mod state;
mod tx_builder;
mod ws;

use std::{str::FromStr, sync::Arc, time::Duration};

use anyhow::{bail, Context, Result};
use clap::Parser;
use dotenvy::dotenv;
use solana_sdk::{pubkey::Pubkey, signer::Signer};
use tokio::time::sleep;
use tracing::{error, info, warn};

use crate::{
    config::AppConfig,
    jupiter::{JupiterClient, SwapInstructionsRequest},
    market_data::MarketDataNormalizer,
    rpc::RpcCtx,
    signal::SignalEngine,
    state::ExecutorState,
    tx_builder::{
        build_execute_trade_transaction, build_prepare_trade_intent_transaction, TradeAccounts,
    },
};

#[derive(Parser, Debug)]
struct Cli {
    #[arg(long, default_value_t = 1)]
    strategy_id: u64,
    #[arg(long)]
    output_mint: String,
    #[arg(long, default_value = "11111111111111111111111111111111")]
    observed_program: String,
    #[arg(long, default_value_t = false)]
    dry_run: bool,
    #[arg(long, default_value_t = true)]
    restrict_intermediate_tokens: bool,
    #[arg(long, default_value_t = true)]
    only_direct_routes: bool,
}

#[tokio::main]
async fn main() -> Result<()> {
    dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    let cli = Cli::parse();
    let cfg = AppConfig::from_env()?;
    let rpc = Arc::new(RpcCtx::new(
        cfg.http_rpc.clone(),
        &cfg.keypair_path,
        cfg.commitment,
    )?);
    let signal_engine = SignalEngine::new(cfg.quote_mint, cfg.max_signal_score);
    let jupiter = JupiterClient::new(cfg.jupiter_api_base.clone(), cfg.jupiter_api_key.as_deref())?;
    let mut state = ExecutorState::default();

    let observed_program = Pubkey::from_str(&cli.observed_program)?;
    let output_mint = Pubkey::from_str(&cli.output_mint)?;
    info!(program_id = %cfg.program_id, observed_program = %observed_program, output_mint=%output_mint, "executor starting");

    let _pubsub = ws::connect_logs(&cfg.ws_rpc, cfg.commitment).await?;
    info!("websocket log subscription established");

    loop {
        let synthetic_live_event = vec![
            "live_event_placeholder_replace_with_real_decoder".to_string(),
            format!("observed_program={observed_program}"),
        ];
        let market_event = MarketDataNormalizer::normalize_logs(
            "pending".to_string(),
            0,
            observed_program,
            &synthetic_live_event,
        )?;

        let decision = signal_engine.evaluate(&market_event, output_mint)?;
        if !decision.should_trade {
            warn!(score = decision.score, "signal below trade threshold");
            sleep(Duration::from_secs(2)).await;
            continue;
        }

        let now = chrono_unix_now();
        if now < state.last_trade_unix_ts + cfg.trade_cooldown_secs {
            warn!("off-chain cooldown active");
            sleep(Duration::from_secs(2)).await;
            continue;
        }

        let quote = jupiter
            .quote(
                decision.input_mint,
                decision.output_mint,
                decision.size_quote,
                cfg.slippage_bps,
                cli.restrict_intermediate_tokens,
                cli.only_direct_routes,
            )
            .await
            .context("failed to fetch Jupiter quote")?;

        let min_out: u64 = quote
            .other_amount_threshold
            .parse()
            .context("invalid Jupiter otherAmountThreshold")?;
        let out_amount: u64 = quote.out_amount.parse().context("invalid Jupiter outAmount")?;

        let strategy_seed = cli.strategy_id.to_le_bytes();
        let nonce_seed = state.nonce.to_le_bytes();
        let (global_config, _) = Pubkey::find_program_address(&[b"config"], &cfg.program_id);
        let (strategy_state, _) =
            Pubkey::find_program_address(&[b"strategy", &strategy_seed], &cfg.program_id);
        let (trade_intent, _) = Pubkey::find_program_address(
            &[b"trade_intent", strategy_state.as_ref(), &nonce_seed],
            &cfg.program_id,
        );
        let (position_state, _) = Pubkey::find_program_address(
            &[
                b"position",
                strategy_state.as_ref(),
                decision.output_mint.as_ref(),
                &0u64.to_le_bytes(),
            ],
            &cfg.program_id,
        );
        let (vault_authority, _) =
            Pubkey::find_program_address(&[b"vault_auth", global_config.as_ref()], &cfg.program_id);
        let (vault_input_ata, _) = Pubkey::find_program_address(
            &[b"vault_token", global_config.as_ref(), decision.input_mint.as_ref()],
            &cfg.program_id,
        );
        let (vault_output_ata, _) = Pubkey::find_program_address(
            &[b"vault_token", global_config.as_ref(), decision.output_mint.as_ref()],
            &cfg.program_id,
        );
        let accounts = TradeAccounts {
            global_config,
            strategy_state,
            trade_intent,
            position_state,
            vault_authority,
            vault_input_ata,
            vault_output_ata,
            input_mint: decision.input_mint,
            output_mint: decision.output_mint,
            jupiter_program: solana_trader::JUPITER_V6_PROGRAM_ID,
        };

        let prep_params = solana_trader::PrepareTradeIntentParams {
            input_mint: decision.input_mint,
            output_mint: decision.output_mint,
            quote_in: decision.size_quote,
            min_out,
            slippage_bps: cfg.slippage_bps,
            expires_at: now + 45,
            nonce: state.nonce,
        };
        let recent_blockhash = rpc.latest_blockhash().await?;
        let prep_tx = build_prepare_trade_intent_transaction(
            rpc.payer.as_ref(),
            cfg.program_id,
            &accounts,
            prep_params,
            recent_blockhash,
        )?;
        rpc.simulate_legacy(&prep_tx).await?;
        if !cli.dry_run {
            rpc.send_and_confirm_legacy(&prep_tx).await?;
        }

        let swap_ix_payload = jupiter
            .swap_instructions(&SwapInstructionsRequest {
                user_public_key: vault_authority.to_string(),
                quote_response: quote.clone(),
                dynamic_compute_unit_limit: true,
                prioritization_fee_lamports: serde_json::json!("auto"),
            })
            .await
            .context("failed to fetch Jupiter swap-instructions")?;

        if swap_ix_payload.token_ledger_instruction.is_some() {
            bail!("tokenLedgerInstruction returned by Jupiter; this scaffold expects pre-created vaults and no token ledger");
        }
        if !swap_ix_payload.setup_instructions.is_empty() {
            bail!("setupInstructions returned by Jupiter; pre-create PDA vault token accounts for both input and output mints before execution");
        }
        if swap_ix_payload.cleanup_instruction.is_some() {
            bail!("cleanupInstruction returned by Jupiter; use token-to-token routes with pre-created vault token accounts for this CPI path");
        }

        let lookup_table_keys = swap_ix_payload
            .address_lookup_table_addresses
            .iter()
            .map(|a| Pubkey::from_str(a))
            .collect::<Result<Vec<_>, _>>()
            .context("invalid Jupiter address lookup table pubkey")?;
        let lookup_tables = rpc
            .load_address_lookup_tables(&lookup_table_keys)
            .await
            .context("failed to load Jupiter address lookup tables")?;

        let trade_tx = build_execute_trade_transaction(
            rpc.payer.as_ref(),
            cfg.program_id,
            &accounts,
            &crate::state::SignalDecision {
                size_base_estimate: out_amount,
                ..decision.clone()
            },
            &swap_ix_payload.compute_budget_instructions,
            &swap_ix_payload.swap_instruction,
            &lookup_tables,
            rpc.latest_blockhash().await?,
        )?;
        rpc.simulate_versioned(&trade_tx).await?;
        if cli.dry_run {
            info!(min_out, out_amount, "dry run enabled; transactions simulated but not sent");
        } else {
            match rpc.send_and_confirm_versioned(&trade_tx).await {
                Ok(sig) => {
                    info!(signature = %sig, min_out, out_amount, "trade submitted successfully");
                    state.last_trade_unix_ts = now;
                    state.nonce = state.nonce.saturating_add(1);
                }
                Err(err) => error!(error = %err, "trade submission failed"),
            }
        }

        sleep(Duration::from_secs(2)).await;
    }
}

fn chrono_unix_now() -> i64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or_default()
}
