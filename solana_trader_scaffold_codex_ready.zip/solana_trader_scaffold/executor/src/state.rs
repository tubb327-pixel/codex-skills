use solana_sdk::pubkey::Pubkey;

#[derive(Debug, Clone)]
pub struct MarketEvent {
    pub signature: String,
    pub slot: u64,
    pub observed_program: Pubkey,
    pub mentions: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct SignalDecision {
    pub should_trade: bool,
    pub score: f64,
    pub input_mint: Pubkey,
    pub output_mint: Pubkey,
    pub side: u8,
    pub size_quote: u64,
    pub size_base_estimate: u64,
}

#[derive(Debug, Clone, Default)]
pub struct ExecutorState {
    pub last_trade_unix_ts: i64,
    pub nonce: u64,
}
