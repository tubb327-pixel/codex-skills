use std::sync::Arc;

use anyhow::{Context, Result};
use solana_client::{
    nonblocking::rpc_client::RpcClient,
    rpc_config::RpcSimulateTransactionConfig,
};
use solana_sdk::{
    address_lookup_table::{program as alt_program, state::AddressLookupTable},
    address_lookup_table_account::AddressLookupTableAccount,
    commitment_config::CommitmentConfig,
    pubkey::Pubkey,
    signature::{read_keypair_file, Keypair, Signature},
    transaction::{Transaction, VersionedTransaction},
};

pub struct RpcCtx {
    pub client: Arc<RpcClient>,
    pub payer: Arc<Keypair>,
    pub commitment: CommitmentConfig,
}

impl RpcCtx {
    pub fn new(http_rpc: String, keypair_path: &std::path::Path, commitment: CommitmentConfig) -> Result<Self> {
        let client = Arc::new(RpcClient::new_with_commitment(http_rpc, commitment));
        let payer = Arc::new(read_keypair_file(keypair_path)?);
        Ok(Self {
            client,
            payer,
            commitment,
        })
    }

    pub async fn latest_blockhash(&self) -> Result<solana_sdk::hash::Hash> {
        Ok(self.client.get_latest_blockhash().await?)
    }

    pub async fn load_address_lookup_tables(
        &self,
        table_addresses: &[Pubkey],
    ) -> Result<Vec<AddressLookupTableAccount>> {
        if table_addresses.is_empty() {
            return Ok(Vec::new());
        }

        let accounts = self
            .client
            .get_multiple_accounts(table_addresses)
            .await
            .context("failed to fetch address lookup table accounts")?;

        let mut tables = Vec::with_capacity(table_addresses.len());
        for (key, maybe_account) in table_addresses.iter().zip(accounts.into_iter()) {
            let account = maybe_account
                .with_context(|| format!("lookup table account missing: {key}"))?;
            if account.owner != alt_program::id() {
                anyhow::bail!("lookup table account {key} has unexpected owner {}", account.owner);
            }
            let table = AddressLookupTable::deserialize(&account.data)
                .map_err(|e| anyhow::anyhow!("failed to deserialize lookup table {key}: {e:?}"))?;
            tables.push(AddressLookupTableAccount {
                key: *key,
                addresses: table.addresses.to_vec(),
            });
        }

        Ok(tables)
    }

    pub async fn simulate_legacy(&self, tx: &Transaction) -> Result<()> {
        let cfg = RpcSimulateTransactionConfig {
            sig_verify: false,
            replace_recent_blockhash: true,
            ..RpcSimulateTransactionConfig::default()
        };
        let sim = self.client.simulate_transaction_with_config(tx, cfg).await?;
        if let Some(err) = sim.value.err {
            anyhow::bail!("simulation failed: {err:?}");
        }
        Ok(())
    }

    pub async fn simulate_versioned(&self, tx: &VersionedTransaction) -> Result<()> {
        let cfg = RpcSimulateTransactionConfig {
            sig_verify: false,
            replace_recent_blockhash: true,
            ..RpcSimulateTransactionConfig::default()
        };
        let sim = self.client.simulate_transaction_with_config(tx, cfg).await?;
        if let Some(err) = sim.value.err {
            anyhow::bail!("simulation failed: {err:?}");
        }
        Ok(())
    }

    pub async fn send_and_confirm_legacy(&self, tx: &Transaction) -> Result<Signature> {
        Ok(self.client.send_and_confirm_transaction(tx).await?)
    }

    pub async fn send_and_confirm_versioned(&self, tx: &VersionedTransaction) -> Result<Signature> {
        Ok(self.client.send_and_confirm_transaction(tx).await?)
    }
}
