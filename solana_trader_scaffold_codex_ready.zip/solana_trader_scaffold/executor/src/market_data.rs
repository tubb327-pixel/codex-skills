use anyhow::Result;
use solana_sdk::pubkey::Pubkey;

use crate::state::MarketEvent;

pub struct MarketDataNormalizer;

impl MarketDataNormalizer {
    pub fn normalize_logs(signature: String, slot: u64, program: Pubkey, logs: &[String]) -> Result<MarketEvent> {
        Ok(MarketEvent {
            signature,
            slot,
            observed_program: program,
            mentions: logs.to_vec(),
        })
    }
}
