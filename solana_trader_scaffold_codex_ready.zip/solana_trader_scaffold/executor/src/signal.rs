use anyhow::Result;
use solana_sdk::pubkey::Pubkey;

use crate::state::{MarketEvent, SignalDecision};

pub struct SignalEngine {
    input_mint: Pubkey,
    signal_threshold: f64,
}

impl SignalEngine {
    pub fn new(input_mint: Pubkey, signal_threshold: f64) -> Self {
        Self {
            input_mint,
            signal_threshold,
        }
    }

    pub fn evaluate(&self, event: &MarketEvent, output_mint: Pubkey) -> Result<SignalDecision> {
        let score = event.mentions.len() as f64;
        Ok(SignalDecision {
            should_trade: score >= 2.0,
            score,
            input_mint: self.input_mint,
            output_mint,
            side: 1,
            size_quote: 100_000,
            size_base_estimate: 0,
        })
    }
}
