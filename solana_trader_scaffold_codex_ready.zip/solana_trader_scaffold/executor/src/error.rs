use thiserror::Error;

#[derive(Debug, Error)]
pub enum ExecutorError {
    #[error("missing environment variable: {0}")]
    MissingEnv(&'static str),
    #[error("signal below threshold")]
    SignalBelowThreshold,
    #[error("cooldown active off-chain")]
    CooldownActive,
}
