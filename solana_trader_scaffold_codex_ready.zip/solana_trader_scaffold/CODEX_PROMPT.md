You are working inside a Solana trading repo that uses:
- one on-chain Anchor program for custody and hard risk controls
- one off-chain Rust executor for Jupiter-based execution
- PDA/vault custody as a non-negotiable requirement
- versioned transactions with ALTs for account-heavy Jupiter routes

Your job is to turn the current Jupiter path into a compile-tested, evidence-backed implementation.

Rules:
1. Do not move to any other venue or module until Jupiter is working.
2. Do not switch to executor-wallet custody as a shortcut.
3. Do not remove or weaken risk controls just to get green tests.
4. Do not claim success without showing the exact command output that proves it.
5. Fix the repo in place with small, reviewable changes.

Required workflow:
1. Read `ARCHITECTURE.md`, `README.md`, and `CODEX_HANDOFF.md` first.
2. Inspect the on-chain program and executor for mismatches.
3. Run:
   - `cargo check --workspace`
   - `anchor build`
   - `npm install`
   - `anchor test --skip-local-validator`
4. Fix any build/test failures.
5. Run the one-shot Jupiter dry-run harness.
6. If the environment supports it, run a real submit on a tiny size after dry-run succeeds.
7. Write a `RESULTS.md` file summarizing what you ran, what passed, what failed, and what remains.

Primary technical goals:
- ensure PDA seeds and bumps match between executor and Anchor program
- ensure TradeIntent serialization and consumption are correct
- ensure Jupiter `swap-instructions` payload is forwarded correctly through `remaining_accounts`
- ensure PDA vault token accounts are used as actual custody source/destination
- ensure v0 transaction compilation and ALT loading work correctly
- ensure unauthorized executor, pause, cooldown, and size/slippage checks fail correctly

Definition of done:
- `cargo check --workspace` passes
- `anchor build` passes
- local tests pass or fail for a clearly explained external reason
- one-shot Jupiter dry-run simulates successfully
- if cluster/account setup allows, one real tiny submit confirms successfully
- `RESULTS.md` contains evidence, not vague claims

Do not broaden scope. Get Jupiter working first.
